<?php

namespace Vendor\Seller\Block\Product;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Vendor\Seller\Model\SellerFactory;

class SellerInfo extends Template
{
    protected $sellerFactory;

    public function __construct(
        Context $context,
        SellerFactory $sellerFactory,
        array $data = []
    ) {
        $this->sellerFactory = $sellerFactory;
        parent::__construct($context, $data);
    }

    public function getSellerInfo()
    {
        $sellerInfo = $this->sellerFactory->create()->load(1);
        return $sellerInfo->getData();
    }
}
