<?php
namespace I95dev\Seller\Model;

class Seller extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('I95dev\Seller\Model\ResourceModel\Seller');
    }
}
?>