<?php

namespace I95dev\Seller\Model\Order;

use Magento\Sales\Model\Order\Item as OrderItem;

class Item extends OrderItem
{
    public function setSellerName($sellerName)
    {
        $this->setData('seller_name', $sellerName);
        return $this;
    }

    public function getSellerName()
    {
        return $this->getData('seller_name');
    }
}
